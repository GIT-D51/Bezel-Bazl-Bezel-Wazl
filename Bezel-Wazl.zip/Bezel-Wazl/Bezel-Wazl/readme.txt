June/9/2025
--------------------------------------------------------------------
Note: This Bezel pack is for RetroArch!
--------------------------------------------------------------------
Hey Adrian here! again....

Thank you for downloading Bezel-Wazl!
-----------------------------------------------------------------------
This approximately took (2 weeks maybe idk) to get everything checked out. And to look as polished as it needed to be.
__________________________________________

NOTE: ISN'T FOR PROFIT UNDER ANY CIRCUMSTANCE FROM BANDAI NAMCO'S OR GCC'S PROPERTY.

(I ALSO DON'T OWN THESE CHARACTERS SUCH: PAC-MAN, MS.PAC-MAN, BLINKY, PINKY, INKY AND CLYDE)

This is a fan-made personal bezel pack.
_______________________________________________________________________________________

(Setting up for your first day!)

Step 1: Unzip it, then Ctrl-X the (Bezel-Wazl file) and locate to overlay on the file: (RetroArchWin64) 
___________________________________________________________________________________

Tip: Right click to your located RetroArch app and click on: (Open file location)
___________________________________________________________________________________

Step 2: Find the overlay file, And paste it to: Borders

Step 3: Go to RetroArch and go to: User Interface

Step 4: Then Go to: (On-Screen Overylay) 

Step 5: Lastly, Click on the file borders and find: Bezel-Wazl

Now you pick whichever bezel you please!

Have fun!
      :  )

-Adrian Contreras

Youtube: @D51-YT
Discord: d51_yt


Both the property of Pac-Man/Ms.Pac-Man is owned Bandai Namco Entertainment Inc and GCC
