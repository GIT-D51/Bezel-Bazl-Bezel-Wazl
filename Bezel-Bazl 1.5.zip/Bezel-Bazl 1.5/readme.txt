June/10/2025
--------------------------------------------------------------------
Note: This Overlay is meant for Mega Bezel only!
--------------------------------------------------------------------
Hey Adrian here! again....

Thank you for downloading Bezel-Bazl!
-----------------------------------------------------------------------
This approximately took 2 days to get everything checked out. And to look as polished as it needed to be.
__________________________________________

NOTE: ISN'T FOR PROFIT UNDER ANY CIRCUMSTANCE FROM BANDAI NAMCO'S OR GCC'S PROPERTY.

(I ALSO DON'T OWN THESE CHARACTERS SUCH: PAC-MAN, MS.PAC-MAN, BLINKY, PINKY, INKY AND CLYDE)

This is a fan-made personal bezel kit.
_______________________________________________________________________________________

(Setting up for your first day!)

Step 1: Ctrl-X the (Bezel-Bazl file) and locate to overlay on the file: (RetroArchWin64) 

Tip: Right click to your located RetroArch app and click on: (Open file location)

Step 2: Find the overlay file, And paste it/Ctrl-V to: Borders

Step 3: Go to RetroArch and go to: User Interface

Step 4: Then Go to: (On-Screen Overylay) 

Step 5: Lastly, Click on the file borders and find: Mega Bezel-Bazl

Now you pick whichever bezel you please!

Have fun!
      :  )

-Adrian Contreras

Youtube: @D51-YT
Discord: d51_yt

Both the property of Pac-Man/Ms.Pac-Man is owned Bandai Namco Entertainment Inc and GCC
